<?php
/**
 * Template Name: Aione Single Post
 */
 ?>

<?php get_header(); ?>

	<div id="primary">
		<div id="mycontent" role="main">
			
			<?php
			$args = array(
					'posts_per_page'   => -1,
					'meta_key'         => '_template_type',
					'meta_value'       => 'single',
					'post_type'        => 'templates',
					'post_status'      => 'publish'
				);
				$templates = get_posts( $args ); //echo "<pre>";print_r($templates);echo "</pre>";
				$data = do_shortcode( $templates[0]->post_content );
				$css = get_post_meta($templates[0]->ID, 'pyre_custom_css',true);
				$data .= "<style>";
				$data .= $css;
				$data .= "</style>";
				echo $data;
			?>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_footer(); ?>